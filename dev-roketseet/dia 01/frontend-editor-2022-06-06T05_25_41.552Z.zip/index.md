#HTMl
- HyperText Marckp Languege

- hiper Text?
-Marcaçao
 -tags
 -atributos
-linguagem
 -maneira de escrever

o que é hipertext?
o que é tag?
o que é hiperkup?
